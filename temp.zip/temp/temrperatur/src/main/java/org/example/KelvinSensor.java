package org.example;

public class KelvinSensor {
    public double getKelvinTemp() {
        return 300.15; // Przykładowe 27°C
    }
}
