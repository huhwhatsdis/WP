package org.example;

public interface TemperatureSensor {
    double getTemperatureCelsius();
}
