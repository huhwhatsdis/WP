package org.example;

public class App {
    public static void main(String[] args) {
        // 1. Tworzymy fizyczne czujniki (Adaptees)
        KelvinSensor kSensor = new KelvinSensor();
        FahrenheitSensor fSensor = new FahrenheitSensor();

        // 2. Tworzymy adaptery, które implementują wspólny interfejs (Target)
        TemperatureSensor kelvinToCelsius = new KelvinAdapter(kSensor);
        TemperatureSensor fahrenheitToCelsius = new FahrenheitAdapter(fSensor);

        // 3. Odczytujemy temperaturę - użytkownik widzi tylko stopnie Celsjusza
        System.out.println("--- System Monitorowania Temperatury ---");

        System.out.print("Odczyt z czujnika Kelvina: ");
        System.out.println(String.format("%.2f", kelvinToCelsius.getTemperatureCelsius()) + " °C");

        System.out.print("Odczyt z czujnika Fahrenheita: ");
        System.out.println(String.format("%.2f", fahrenheitToCelsius.getTemperatureCelsius()) + " °C");
    }
}