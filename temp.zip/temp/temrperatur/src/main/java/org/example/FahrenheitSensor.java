package org.example;

public class FahrenheitSensor {
    public double getFahrenheitTemp() {
        return 86.0; // Przykładowe 30°C
    }
}