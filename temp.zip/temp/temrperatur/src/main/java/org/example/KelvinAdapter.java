package org.example;

public class KelvinAdapter implements TemperatureSensor {
    private KelvinSensor sensor;

    public KelvinAdapter(KelvinSensor sensor) {
        this.sensor = sensor;
    }

    @Override
    public double getTemperatureCelsius() {
        return sensor.getKelvinTemp() - 273.15;
    }
}