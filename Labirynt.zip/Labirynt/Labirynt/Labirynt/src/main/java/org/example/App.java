package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class App extends JFrame
{
    private JMyPanel panel;
    private Image image;
    private Maze maze;

    public App() {
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        panel = new JMyPanel();
        JButton button = new JButton("Draw maze");
        button.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            image = panel.getImage();
            maze = null;
            Graphics g = image.getGraphics();
            g.clearRect(0, 0, image.getWidth(null), image.getHeight(null));

            drawMaze();
            drawMazeFactory();
            drawMazesUsingBuilder();
            panel.repaint();
            }
        });

        JButton buttonDet = new JButton("Detonation");
        buttonDet.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                image = panel.getImage();
                drawBombedMaze();
                panel.repaint();
            }
        });

        setLayout((new BorderLayout()));
        JPanel menuPanel = new JPanel(new GridLayout(1, 2));
        menuPanel.add(button);
        menuPanel.add(buttonDet);
        add(menuPanel, "North");
        add(panel, BorderLayout.CENTER);

    }

    public void drawBombedMaze(){
        if (image == null) image = panel.getImage();
        if (maze == null) return;
        for (int i = 0; i < maze.size(); i++){
            MapSite roomObj = maze.getRoomAt(i);
            if (roomObj instanceof RoomWithBomb) {
                RoomWithBomb room = (RoomWithBomb) roomObj;
                room.detonate();
                for (Directions d : Directions.values()) {
                    int nx = room.getX();
                    int ny = room.getY();
                    switch (d) {
                        case North -> ny = room.getY() - MapSite.LENGTH;
                        case South -> ny = room.getY() + MapSite.LENGTH;
                        case East -> nx = room.getX() + MapSite.LENGTH;
                        case West -> nx = room.getX() - MapSite.LENGTH;
                    }
                    Room neighbor = maze.getRoomByCoordinates(nx, ny);
                    if (neighbor != null) {
                        Directions opp = switch (d) {
                            case North -> Directions.South;
                            case South -> Directions.North;
                            case East -> Directions.West;
                            case West -> Directions.East;
                        };
                        MapSite side = neighbor.getSide(opp);
                        if (side instanceof Wall) {
                            ((Wall) side).setExploded(true);
                        }
                    }
                }
            }
        }
        maze.draw(image);
        panel.repaint();
    }

    public void drawMazeFactory(){
        int x = 50;
        int y = 100;
        int nr = 1;

        MazeFactory mazeFactory = new BombedMazeFactory(x, y);
        this.maze = mazeFactory.createMaze();
        if (image == null) image = panel.getImage();
        if (this.maze != null) this.maze.draw(image);
    }

    public void drawMaze() {
        Wall wall = new Wall(Directions.East);
        wall.setX(50);
        wall.setY(100);
        wall.draw(image);
        int x = 50;
        int y = 100;
        int nr = 1;

        Room room1 = new Room(1,50,100);
        room1.setSide(Directions.North, new Wall(Directions.North));
        room1.setSide(Directions.East, new Wall(Directions.East));
        room1.setSide(Directions.South, new Wall(Directions.South));
        room1.setSide(Directions.West, new Wall(Directions.West));

        Room room2 = new Room(2,50,100 + MapSite.LENGTH);
        room2.setSide(Directions.North, new Wall(Directions.North));
        room2.setSide(Directions.East, new Wall(Directions.East));
        room2.setSide(Directions.South, new Wall(Directions.South));
        room2.setSide(Directions.West, new Wall(Directions.West));

        Room room3 = new Room(3,50,100 + 2*MapSite.LENGTH);
        room3.setSide(Directions.North, new Wall(Directions.North));
        room3.setSide(Directions.East, new Wall(Directions.East));
        room3.setSide(Directions.South, new Wall(Directions.South));
        room3.setSide(Directions.West, new Wall(Directions.West));

        Room room9 = new Room(9, 50, 100 + 3 * MapSite.LENGTH);
        room9.setSide(Directions.North, new Wall(Directions.North));
        room9.setSide(Directions.East, new Wall(Directions.East));
        room9.setSide(Directions.South, new Wall(Directions.South));
        room9.setSide(Directions.West, new Wall(Directions.West));

        RoomWithBomb room10 = new RoomWithBomb(10, 50, 100 + 4 * MapSite.LENGTH);
        room10.setSide(Directions.North, new Wall(Directions.North));
        room10.setSide(Directions.East, new Wall(Directions.East));
        room10.setSide(Directions.South, new Wall(Directions.South));
        room10.setSide(Directions.West, new Wall(Directions.West));
        room10.setBomb(true);

        Room room11 = new Room(11, 50, 100 + 5 * MapSite.LENGTH);
        room11.setSide(Directions.North, new Wall(Directions.North));
        room11.setSide(Directions.East, new Wall(Directions.East));
        room11.setSide(Directions.South, new Wall(Directions.South));
        room11.setSide(Directions.West, new Wall(Directions.West));

        RoomWithBomb room12 = new RoomWithBomb(12, x + MapSite.LENGTH, y + 5 * MapSite.LENGTH);
        room12.setSide(Directions.North, new Wall(Directions.North));
        room12.setSide(Directions.East, new Wall(Directions.East));
        room12.setSide(Directions.South, new Wall(Directions.South));
        room12.setSide(Directions.West, new Wall(Directions.West));
        room12.setBomb(true);


        Room room4 = new Room(4,50 + MapSite.LENGTH,100 + MapSite.LENGTH);
        room4.setSide(Directions.North, new Wall(Directions.North));
        room4.setSide(Directions.East, new Wall(Directions.East));
        room4.setSide(Directions.South, new Wall(Directions.South));
        room4.setSide(Directions.West, new Wall(Directions.West));

        Room room5 = new Room(5,50 + 2*MapSite.LENGTH,100);
        room5.setSide(Directions.North, new Wall(Directions.North));
        room5.setSide(Directions.East, new Wall(Directions.East));
        room5.setSide(Directions.South, new Wall(Directions.South));
        room5.setSide(Directions.West, new Wall(Directions.West));

        Room room6 = new Room(6,50 + 2*MapSite.LENGTH,100 + MapSite.LENGTH);
        room6.setSide(Directions.North, new Wall(Directions.North));
        room6.setSide(Directions.East, new Wall(Directions.East));
        room6.setSide(Directions.South, new Wall(Directions.South));
        room6.setSide(Directions.West, new Wall(Directions.West));

        Room room7 = new Room(7,50 + 2*MapSite.LENGTH,100 + 2*MapSite.LENGTH);
        room7.setSide(Directions.North, new Wall(Directions.North));
        room7.setSide(Directions.East, new Wall(Directions.East));
        room7.setSide(Directions.South, new Wall(Directions.South));
        room7.setSide(Directions.West, new Wall(Directions.West));

        Room room8 = new Room(8,50 + 3*MapSite.LENGTH,100 + MapSite.LENGTH);
        room8.setSide(Directions.North, new Wall(Directions.North));
        room8.setSide(Directions.East, new Wall(Directions.East));
        room8.setSide(Directions.South, new Wall(Directions.South));
        room8.setSide(Directions.West, new Wall(Directions.West));

        
        Door door1 = new Door(room1,room2,false);
        Door door2 = new Door(room2,room3,false);
        Door door3 = new Door(room2,room4,true);
        Door door4 = new Door(room4,room6,true);
        Door door5 = new Door(room6,room5,false);
        Door door6 = new Door(room6,room7,false);
        Door door7 = new Door(room6,room8,true);
        Door door8  = new Door(room3, room9, false);
        Door door9  = new Door(room9, room10, false);
        Door door10 = new Door(room10, room11, false);
        Door door11 = new Door(room11, room12, false);

        Maze maze = new Maze();
        maze.addRoom(room1);
        maze.addRoom(room2);
        maze.addRoom(room3);
        maze.addRoom(room4);
        maze.addRoom(room5);
        maze.addRoom(room6);
        maze.addRoom(room7);
        maze.addRoom(room8);
        maze.addRoom(room9);
        maze.addRoom(room10);
        maze.addRoom(room11);
        maze.addRoom(room12);

        maze.draw(image);


        room1.draw(image);
        room2.draw(image);
        room3.draw(image);
        room4.draw(image);
        room5.draw(image);
        room6.draw(image);
        room7.draw(image);
        room8.draw(image);
        room9.draw(image);
        room10.draw(image);
        room11.draw(image);
        room12.draw(image);



    }


    public void drawMazesUsingBuilder() {
        Director director = new Director();
        MazeBuilder builder1 = new ConcreteBuilderLevel1();
        MazeBuilder builder2 = new ConcreteBuilderLevel1();

        image = panel.getImage();

        director.createMaze(builder1);
        Maze maze1 = builder1.getMaze();
        maze1.draw(image);

        director.createMazeWithOffset(builder2, 400);
        Maze maze2 = builder2.getMaze();
        maze2.draw(image);
    }


    public static void main( String[] args )
    {

        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new App().setVisible(true);
            }
        });
    }
}