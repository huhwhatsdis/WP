package org.example;


import java.awt.Image;

public class Room extends MapSite{
    private int nr;
    private MapSite[] sites = new MapSite[4];
    protected boolean destroyed = false;
    private int roomNumber;

    public int getRoomNumber() {
        return roomNumber;
    }

    public Room (int nr, int x, int y){
        super(x,y);
        this.nr = nr;
    }

    public void explode() {
        destroyed = true;
    }

    public boolean isDestroyed() {
        return destroyed;
    }

    public int getRoomNr() {
        return nr;
    }

    public void setSide(Directions d, MapSite mapSite){
        if (mapSite instanceof Wall){
            switch (d) {
                case North, West:
                    mapSite.setX(getX());
                    mapSite.setY(getY());
                    break;
                case East:
                    mapSite.setX(getX() + MapSite.LENGTH);
                    mapSite.setY(getY());
                    break;
                case South:
                    mapSite.setX(getX());
                    mapSite.setY(getY()+MapSite.LENGTH);
            }
            if (mapSite instanceof  Wall) {
                ((Wall) mapSite).setDirection(d);
            }
        }
        sites[d.ordinal()] = mapSite;
    }

    protected MapSite[] getSides(){
        return sites;
    }

    public MapSite getSide(Directions d){
        return sites[d.ordinal()];
    }

    public int getNr(){
        return nr;
    }

    @Override
    public void draw(Image image){
        super.draw(image);
        for (MapSite mapSite: sites)
            if (mapSite != null)
                mapSite.draw(image);
    }

}
