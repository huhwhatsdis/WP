package org.example;

import java.util.Random;

public class Socket230V {
    public double getVoltege230V(){
        return 230 + rand(46) - 23;
    }
    private Random rand = new Random();
}
