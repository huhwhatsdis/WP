package org.example;

import java.util.Random;

public class Socket110V {
    public double getVoltege110V(){
        return 110 - rand(22) - 11;
    }
    private Random rand = new Random();
}
