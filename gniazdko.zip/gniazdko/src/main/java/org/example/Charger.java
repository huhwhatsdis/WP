package org.example;

public interface Charger {
    public double getVoltege5V();
}
