package org.example;

public class Main {
    Socket230V socket230V = new Socket230V();
    System.out.println("Napięcie: " + socket.getSocket230V());
    ChargerAdapter charger = new ChargerAdapter(socket230V);
    System.out.println("Napięce z zasilania: " + charger.getVoltege5V());

    Socket110V socket110V = new Socket110V();

    ChargerAdapter charger2 = new ChargerAdapter(socket110V);
    System.out.println("Napięcie z zasilania: " + charger2.getVoltege5V());
}
