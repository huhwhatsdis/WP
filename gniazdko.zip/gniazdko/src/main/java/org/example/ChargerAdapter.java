package org.example;

public class ChargerAdapter implements Charger{
    private Socket230V socket230V;

    public ChargerAdapter(Socket230V socket){
        socket230V = socket;
    }
    @Override
    public getVoltege5V(){
        return socket230V.getVoltege230V() / 46;
    }
}
