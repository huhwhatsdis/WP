package org.example;

import javax.swing.*;

public class MyTextView extends JTextField implements IView {

    public MyTextView(int size) {
        super(size);
        setEditable(false);
    }

    @Override
    public void setText(String data) {
        super.setText(data);
    }

    public String getTextValue() {
        return getText();
    }
}
