package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class App extends JFrame {

    private MyTextView screen;
    private MyGraphicsView screenGr;
    private CalculatorModel model = new CalculatorModel();

    private JButton button_1 = new JButton("1");
    private JButton button_2 = new JButton("2");
    private JButton button_3 = new JButton("3");
    private JButton button_4 = new JButton("4");
    private JButton button_5 = new JButton("5");
    private JButton button_6 = new JButton("6");
    private JButton button_7 = new JButton("7");
    private JButton button_8 = new JButton("8");
    private JButton button_9 = new JButton("9");
    private JButton button_0 = new JButton("0");
    private JButton button_add = new JButton("+");
    private JButton button_substract = new JButton("-");
    private JButton button_divide = new JButton("/");
    private JButton button_multiply = new JButton("*");
    private JButton button_equal = new JButton("=");
    private JButton button_C = new JButton("C");
    private JButton button_backspace = new JButton("<-");

    private IView[] views;

    public App() {
        JPanel panel = new JPanel(new BorderLayout());

        screen = new MyTextView(10);
        screenGr = new MyGraphicsView();
        screenGr.setPreferredSize(new Dimension(200,50));

        views = new IView[]{screen, screenGr};

        panel.add(screen, BorderLayout.NORTH);
        panel.add(screenGr, BorderLayout.SOUTH);

        JPanel panelButtons = new JPanel(new GridLayout(5,4));

        JButton[] nums = {button_0,button_1,button_2,button_3,button_4,button_5,button_6,button_7,button_8,button_9};

        ActionListener numberListener = e -> {
            String digit = e.getActionCommand();
            if(model.isStartNewNumber()) {
                updateViews(digit);
                model.setStartNewNumber(false);
            } else {
                updateViews(screen.getTextValue() + digit);
            }
        };

        for(JButton b : nums) b.addActionListener(numberListener);

        ActionListener operatorListener = e -> {
            double value = Double.parseDouble(screen.getTextValue());
            model.inputOperator(e.getActionCommand(), value);
        };

        button_add.addActionListener(operatorListener);
        button_substract.addActionListener(operatorListener);
        button_multiply.addActionListener(operatorListener);
        button_divide.addActionListener(operatorListener);

        button_equal.addActionListener(e -> {
            double second = Double.parseDouble(screen.getTextValue());
            double result = model.calculate(second);
            updateViews(String.valueOf(result));
            model.setStartNewNumber(true);
        });

        button_C.addActionListener(e -> {
            model.clear();
            updateViews("");
        });

        button_backspace.addActionListener(e -> {
            String text = screen.getTextValue();
            if(text.length()>0)
                updateViews(text.substring(0,text.length()-1));
        });

        panelButtons.add(button_7); panelButtons.add(button_8); panelButtons.add(button_9); panelButtons.add(button_divide);
        panelButtons.add(button_4); panelButtons.add(button_5); panelButtons.add(button_6); panelButtons.add(button_multiply);
        panelButtons.add(button_1); panelButtons.add(button_2); panelButtons.add(button_3); panelButtons.add(button_substract);
        panelButtons.add(button_C); panelButtons.add(button_0); panelButtons.add(button_backspace); panelButtons.add(button_add);
        panelButtons.add(new JLabel()); panelButtons.add(new JLabel()); panelButtons.add(new JLabel()); panelButtons.add(button_equal);

        panel.add(panelButtons, BorderLayout.CENTER);

        setContentPane(panel);
        pack();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void updateViews(String text) {
        for(IView v : views) v.setText(text);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(App::new);
    }
}
