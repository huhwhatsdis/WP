package org.example;

import javax.swing.*;
import java.awt.*;

public class MyGraphicsView extends JPanel implements IView {

    private String text = "";

    @Override
    public void setText(String data) {
        this.text = data;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.RED);
        g.drawString(text, 10, getHeight()/2);
    }
}
