package org.example;

public class CalculatorModel {

    private double firstNumber = 0;
    private String operator = "";
    private boolean startNewNumber = true;

    public void inputOperator(String op, double value) {
        firstNumber = value;
        operator = op;
        startNewNumber = true;
    }

    public double calculate(double secondNumber) {
        switch (operator) {
            case "+": return firstNumber + secondNumber;
            case "-": return firstNumber - secondNumber;
            case "*": return firstNumber * secondNumber;
            case "/": return secondNumber != 0 ? firstNumber / secondNumber : 0;
            case "+/-": return firstNumber * -1;
            default: return secondNumber;
        }
    }

    public boolean isStartNewNumber() {
        return startNewNumber;
    }

    public void setStartNewNumber(boolean b) {
        startNewNumber = b;
    }

    public void clear() {
        firstNumber = 0;
        operator = "";
        startNewNumber = true;
    }
}
