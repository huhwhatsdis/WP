package org.example;

public interface IView {
    void setText(String data);
}
