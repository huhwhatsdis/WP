package org.example;

public class IView {
}
