package org.example;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class App extends JFrame implements ActionListener{
    private JTextField screen;
    private MyGraphicsView screenGr;
    private JButton button_1 = new JButton("1");
    private JButton button_2 = new JButton("2");
    private JButton button_3 = new JButton("3");
    private JButton button_4 = new JButton("4");
    private JButton button_5 = new JButton("5");
    private JButton button_6 = new JButton("6");
    private JButton button_7 = new JButton("7");
    private JButton button_8 = new JButton("8");
    private JButton button_9 = new JButton("9");
    private JButton button_0 = new JButton("0");
    private JButton button_add = new JButton("+");
    private JButton button_substract = new JButton("-");
    private JButton button_divide = new JButton("/");
    private JButton button_multiply = new JButton("*");
    private JButton button_equal = new JButton("=");
    private JButton button_C = new JButton("C");
    private JButton button_backspace = new JButton("<-");
    private String text = "";

    @Override
    public void actionPerformed(ActionEvent e) {
        Object source = e.getSource();
        if (source instanceof JButton) {
            String digit = ((JButton) source).getText();
            text += digit;
            screen.setText(text);
        }
    }

    public App() {
        JPanel panel = new JPanel(new BorderLayout());
        screen = new JTextField(10);
        screenGr = new MyGraphicsView();
        screenGr.setPreferredSize(new Dimension(200,50));
        panel.add("North", screen);
        panel.add("South",screenGr);
        JPanel panelButtons = new JPanel(new GridLayout(5, 4));

        button_9.addActionListener(this);
        panelButtons.add(button_9);

        button_8.addActionListener(this);
        panelButtons.add(button_8);

        button_7.addActionListener(this);
        panelButtons.add(button_7);

        button_divide.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (!text.equals("") && !text.contains(" ")){
                    screen.setText(text + " / ");
                }
            }

        });
        panelButtons.add(button_divide);

        button_6.addActionListener(this);
        panelButtons.add(button_6);

        button_5.addActionListener(this);
        panelButtons.add(button_5);

        button_4.addActionListener(this);
        panelButtons.add(button_4);

        button_multiply.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (!text.equals("") && !text.contains(" ")){
                    screen.setText(text + " * ");
                }
            }
        });
        panelButtons.add(button_multiply);

        button_3.addActionListener(this);
        panelButtons.add(button_3);

        button_2.addActionListener(this);
        panelButtons.add(button_2);

        button_1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                screen.setText( text + "1");

            }
        });
        panelButtons.add(button_1);

        button_substract.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (!text.equals("") && !text.contains(" ")){
                    screen.setText(text + " - ");
                }
            }
        });
        panelButtons.add(button_substract);

        button_C.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                screen.setText("");
            }
        });
        panelButtons.add(button_C);

        button_0.addActionListener(this);
        panelButtons.add(button_0);

        button_backspace.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (text.length() > 0) {
                    screen.setText(text.substring(0, text.length() - 1));
                }
            }
        });
        panelButtons.add(button_backspace);

        button_add.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String text = screen.getText();
                if (!text.equals("") && !text.contains(" ")){
                    screen.setText(text + " + ");
                }
            }
        });
        panelButtons.add(button_add);
        panelButtons.add(new JLabel());
        panelButtons.add(new JLabel());
        panelButtons.add(new JLabel());

        panelButtons.add(button_equal);

        panel.add("Center", panelButtons);
        setContentPane(panel);
        pack();
        setVisible(true);
    }


    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new App();
            }
        });

    }

}